import { BASE_URL } from '../../configs/config';

export const index = '/';
