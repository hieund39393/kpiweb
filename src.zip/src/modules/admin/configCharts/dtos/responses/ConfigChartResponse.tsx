export interface ConfigChartProps {
    id: number
    type: number
    code: number
    moTa: string
    tenCauHinh: string
    giaTri1: string
    giaTri2: string
    giaTri3: string
}