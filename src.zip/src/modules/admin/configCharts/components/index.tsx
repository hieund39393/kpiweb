import Table from './table';
import '../configChart.css'

export default function Index() {
    return (
        <Table />
    )
}
