import { BASE_URL } from "configs/config";

export const list = BASE_URL + 'cau-hinh-bieu-do/list';
export const get = BASE_URL + 'cau-hinh-bieu-do/get';
export const create = BASE_URL + 'cau-hinh-bieu-do/create';
export const update = BASE_URL + 'cau-hinh-bieu-do/update';
export const remove = BASE_URL + 'cau-hinh-bieu-do/delete';