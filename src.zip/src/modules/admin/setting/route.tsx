import { BASE_URL } from "configs/config"


export const list = BASE_URL + 'cau-hinh/list'
export const create = BASE_URL + 'cau-hinh/create'
export const update = BASE_URL + 'cau-hinh/update'
export const remove = BASE_URL + 'cau-hinh/delete'
export const search = BASE_URL + 'cau-hinh/search'