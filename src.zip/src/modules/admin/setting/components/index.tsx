import Table from './table';
import '../assets/css/config.css';

export default function CauHinhChung() {
	return (
		<Table />
	)
}