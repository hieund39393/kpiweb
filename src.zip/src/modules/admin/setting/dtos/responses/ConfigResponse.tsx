export interface ConfigProps {
    id: number
    tenCauHinh: string
    giaTri: number
    moTa: string
}