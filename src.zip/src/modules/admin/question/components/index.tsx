import Table from "./table";

const Question = () => {
    return (
        <>
            <Table />
        </>
    )
}

export default Question;