export const QuestionReponse = {
    ID: 0,
    cauHoi: "",
    thuTuHienThi: ""
}
