export const QuestionRequest = {
    ID: null,
    cauHoi: "",
    thuTuHienThi: 0
}
