import Table from './table';
export default function index() {
  return (
    <Table />
  )
}