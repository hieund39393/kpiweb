import Table from './table';
import '../assets/css/syncConfig.css';

export default function CauHinhDongBo() {
	return (
		<Table />
	)
}