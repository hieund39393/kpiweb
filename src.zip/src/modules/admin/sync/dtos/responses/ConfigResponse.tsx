export interface ConfigProps {
    id: number
    tenCauHinh: string,
    moTa: string
}