import { BASE_URL } from "../../../configs/config"


export const list = BASE_URL + 'cau-hinh-dong-bo/list'
export const get = BASE_URL + 'cau-hinh-dong-bo/get'
export const update = BASE_URL + 'cau-hinh-dong-bo/update'