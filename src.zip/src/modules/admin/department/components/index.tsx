import Table from "./table";

const DonVi = () => {
    return (
        <>
            <Table />
        </>
    )
}

export default DonVi;