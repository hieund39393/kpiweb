export const DepartmentReponse = {
    ID: 0,
    MaDonVi: "",
    TenDonVi: ""
}
