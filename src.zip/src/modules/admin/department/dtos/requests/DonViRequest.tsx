export interface DonViProps {
  id: number
  maDonVi: string
  tenDonVi: string
  laTongCongTy: boolean
}
