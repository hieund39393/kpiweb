import Table from "./table";

function TaiKhoan() {
    return (
        <Table />
    )
}

export default TaiKhoan;