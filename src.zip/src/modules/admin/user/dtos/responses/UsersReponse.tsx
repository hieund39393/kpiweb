export const UsersReponse = {
    ID: 0,
    TenDonVi: "",
    TenDangNhap: "",
    MatKhau: "",
    TenDayDu: "",
    Email: "",
    Quyen: false
}
