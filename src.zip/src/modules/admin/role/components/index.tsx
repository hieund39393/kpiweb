import Table from "./table";
import '../role.css';

export default function QuyenTaiKhoan() {
  return (
    <Table />
  )
}

