export interface RoleProps {
  id: number
  tenQuyen: string
  ghiChu: string
  chucNangIDs: string
}

export interface ChucNangProps {
  id: number
  tenController: string
  tenChucNang: string
  chucNangChaID: number
}
