export const QuyenHeThongReponse = {
    ID: 0,
    TenQuyen: "",
    MoTa: "",
}
