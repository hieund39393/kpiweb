import Table from './table'

export default function Index() {
    return (
        <Table />
    )
}