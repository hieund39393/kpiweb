import Table from './table'
import '../style.css'
function Perform() {
    return (
        <Table />
    )
}

export default Perform;