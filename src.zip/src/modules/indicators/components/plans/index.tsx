import Table from './table'
import '../style.css'
function Plans() {
    return (
        <Table />
    )
}

export default Plans;