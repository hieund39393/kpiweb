import { Layout } from 'antd';
const { Footer } = Layout;

function FooterSection() {
  return <Footer>EVN KPI ©2021</Footer>;
}

export default FooterSection;
