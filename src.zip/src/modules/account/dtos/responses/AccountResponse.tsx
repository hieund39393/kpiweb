export const AccountResponse = {    
    NguoiDungID: 0,
    HoTen: "",
    Token: ""    
}
