export const LoginRequest = {    
    TenDangNhap: "",    
    MatKhau : "",
    RememberMe: false
}
