import Table from './table';
import '../report.css'

export default function ByIndicators() {
  return (
    <Table />
  )
}