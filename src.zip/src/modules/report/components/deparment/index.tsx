import Table from './table';
import '../report.css'

export default function ByDeparment() {
  return (
    <Table />
  )
}