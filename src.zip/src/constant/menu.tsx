export const _BOCHITIEUKYTHUAT = 'boChiTieuKyThuat';
export const _BOCHITIEUKINHDOANH = 'boChiTieuKinhDoanh';
export const _BOCHITIEUXAYDUNG = 'boChiTieuXayDung';
export const _BOCHITIEUSUACHUA = 'boChiTieuSuaChua';
export const _BOCHITIEUQUANTRI = 'boChiTieuQuanTri';
export const _BOCHITIEUTAICHINH = 'boChiTieuTaiChinh';
export const _BOCHITIEUANTOAN = 'boChiTieuAnToan';
export const _BOCHITIEUCHUYENDOISO = 'boChiTieuChuyenDoiSo';
export const _BOCHITIEUTHANHTRAKIEMTRA = 'boChiTieuThanhTraKiemTra';
export const _BOCHITIEUBAOCAODIEUHANH= 'boChiTieuBaoCaoDieuHanh';

export const _THEODONVI = 'theoDonVi';
export const _THEOCHITIEU = 'theoChiTieu';
export const _BAOCAO = 'baoCao';