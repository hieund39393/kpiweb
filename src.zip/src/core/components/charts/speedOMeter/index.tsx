function SpeedOMeterChart(){
    
}

export default SpeedOMeterChart;