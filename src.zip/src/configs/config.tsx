export const BASE_URL = 'http://localhost:5000/api/';
//export const BASE_URL = 'http://10.9.8.157:3333/api/';
export const TIMEOUT = 20000;